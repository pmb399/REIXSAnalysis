# Global Dictionary with edges
EdgeDict = dict()
EdgeDict["O"] = (480,580)
EdgeDict["N"] = (360,430)
